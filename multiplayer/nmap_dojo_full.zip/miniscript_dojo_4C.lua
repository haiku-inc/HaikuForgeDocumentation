unlockApp("mini")
unlockApp("cd")
unlockApp("pwd")
unlockApp("cat")
unlockApp("head")
unlockApp("tail")
unlockApp("less")
unlockApp("ls")
unlockApp("rm")
unlockApp("cp")
unlockApp("mv")
unlockApp("mkdir")
unlockApp("dust")
unlockApp("touch")
unlockApp("strings")
unlockApp("realpath")
unlockApp("ping")
unlockApp("nmap")
unlockApp("ssh")
unlockApp("iptables")
unlockApp("ifconfig")
unlockApp("netstat")
unlockApp("ps")
unlockApp("kill")
unlockApp("md5sum")
unlockApp("unzip")
unlockApp("clear")
unlockApp("exit")
unlockApp("echo")
unlockApp("grep")
unlockApp("man")
unlockApp("dd")
unlockApp("flag")
unlockApp("flags")

deviceNames = [ 
	"N_3_Workstation_04", 
	"N_3_Workstation_05", 
	"N_3_Workstation_03", 
	"N_3_Workstation_02", 
	"N_3_Workstation_01", 
	"N_3_Server_FTP_01", 
	"N_3_Server_Web_01", 
	"N_3_Server_SSH", 
	"N_3_Server_Mail" ]
	
if get_mission_dictionary_value("tutorial_flag_created") == null then
	downloadFile("", "Home System", "/Secret Folder", [ "Immutable", "Directory" ])
	clearFileAttributes("Home System", "/Secret Folder")
	
	downloadFile("", "Home System", "/Secret Folder/flaggedfile")
	clearFileAttributes("Home System", "/Secret Folder/flaggedfile")
	addFileAttribute("Home System", "/Secret Folder/flaggedfile", "Immutable")
end if

if get_session_data_value("network_init") == null then
	userNames = [
		"James",
		"Mary",
		"Robert",
		"Patricia",
		"John",
		"Jennifer",
		"Michael",
		"Linda",
		"David",
		"Elizabeth",
		"William",
		"Barbara",
		"Richard",
		"Susan", 
		"Joseph",
		"Jessica",
		"Thomas",
		"Sarah",
		"Charles",
		"Karen",
		"Christopher",
		"Lisa",
		"Daniel",
		"Nancy",
		"Matthew",
		"Betty" ]
	
	operatingSystems = [
		{ "name": "Ubuntu", "versions": [ "22.04 LTS", "20.04.4 LTS", "18.04.6 LTS", "16.04.7 LTS", "14.04.6 LTS" ] },
		{ "name": "CentOS", "versions": [ "Linux 7 distribution", "Linux 8 distribution", "Stream 9" ] },
		{ "name": "Fedora", "versions": [ "35", "36", "37", "38" ] },
		{ "name": "Debian", "versions": [ "9 (stretch)", "8 (jessie)", "7 (wheezy)", "6.0 (squeeze)" ] },
		{ "name": "Red Hat Enterprise Linux", "versions" : [ "RHEL 9.0", "RHEL 8.6", "RHEL 8.5", "RHEL 8.4", "RHEL 8.3" ] },
		{ "name": "Linux Mint", "versions" : [ "21", "20.3", "20.2", "20.1", "20" ] },
		{ "name": "OpenSUSE", "versions" : [ "Leap 15.4", "Leap 15.1", "Leap 15.0", "Leap 42.3", "Leap 42.2" ] } ]
	
	charactersForPassword = [ "a", "b", "c", "d", "e", "f", "g", "h", "j", "k", "m", "n", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" ]
	
	services = [
		{ "service": "Ftp", "number": 21, "versions": [ "FTPv1", "FTPv2", "FTPv3", "FTPv4", "FTPv5", "FTPv6" ] },
		{ "service": "Smtp", "number": 25, "versions": [ "SMTPv1.0.1", "SMTPv2", "SMTPv4" ] },
		{ "service": "Dns", "number": 53, "versions": [ "DNSv1", "DNSv2" ] },
		{ "service": "Tftp", "number": 69, "versions": [ "TFTPv1", "TFTPv2", "TFTPv3" ] },
		{ "service": "Http", "number": 80, "versions": [ "HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2" ] },
		{ "service": "Pop3", "number": 110, "versions": [ "POP3v1", "POP3v2", "POP3v3" ] },
		{ "service": "Nntp", "number": 119, "versions": [ "NNTPv1", "NNTPv2" ] },
		{ "service": "Ntp", "number": 123, "versions": [ "NTPv2", "NTPv3", "NTPv4" ] },
		{ "service": "Imap4", "number": 143, "versions": [ "IMAP4v1" ] },
		{ "service": "Snmp", "number": 161, "versions": [ "SNMPv1", "SNMPv2", "SNMPv3" ] },
		{ "service": "Https", "number": 443, "versions": [ "HTTPSv1" ] },
		{ "service": "Dhcp", "number": 547, "versions": [ "IPv4", "IPv6" ] },
		{ "service": "Upnp", "number": 1900, "versions": [ "1.0", "1.1", "2.0", "3.0", "4.0" ] } ]
		
	
	for deviceName in deviceNames
		userNameIndex = round(rnd() * (userNames.len() - 1))
		userName = userNames[userNameIndex].lower()
		userNames.remove(userNameIndex)
		
		passwordLength = round(rnd() * 11) + 1
		password = ""
		passwordCounter = 0
		while passwordCounter < passwordLength
			characterIndex = round(rnd() * (charactersForPassword.len() - 1))
			password = password + charactersForPassword[characterIndex]
			
			passwordCounter = passwordCounter + 1
		end while
		
		computerName = userName + "_pc"
		usernamePostfix = round(rnd() * 899) + 100
		userName = userName + "_" + usernamePostfix
		
		operatingSystemIndex = round(rnd() * (operatingSystems.len() - 1))
		operatingSystem = operatingSystems[operatingSystemIndex]
		osVersion = operatingSystem.versions[round(rnd() * (operatingSystem.len() - 1))]
		
		set_device_computer_name(deviceName, computerName)
		users = [ { "username": userName, "password": password } ]
		set_device_users(deviceName, users)
		set_device_os(deviceName, operatingSystem.name)
		set_device_os_version(deviceName, osVersion)
		
		servicesCopy = []
		for service in services
			servicesCopy.push(service)
		end for
		
		servicesForDevice = [ { "service": "Ssh", "number": 22, "version": "SSH-2" } ]
		
		serviceCounter = 0
		while serviceCounter < 4
			serviceIndex = round(rnd() * (servicesCopy.len() - 1))
			service = servicesCopy[serviceIndex];
			servicesCopy.remove(serviceIndex)
			
			versionIndex = round(rnd() * (service.versions.len() - 1))
			version = service.versions[versionIndex]
			
			servicesForDevice.push({ "service": service.service, "number": service.number, "version": version })
			
			serviceCounter = serviceCounter + 1
		end while
		
		servicesCopy = []
		set_device_port_list(deviceName, servicesForDevice)
	end for

	flagDeviceNames = []

	deviceNamesCopy = []
	for device in deviceNames
		deviceNamesCopy.push(device)
	end for
	
	deviceCounter = 0
	while deviceCounter < 5
		index = round(rnd() * (deviceNamesCopy.len() - 1))
		name = deviceNamesCopy[index]
		deviceNamesCopy.remove(index)
		flagDeviceNames.push(name)
		
		deviceCounter = deviceCounter + 1
	end while
	
	deviceCounter = 0
	while deviceCounter < 5
		name = flagDeviceNames[deviceCounter]
	
		if deviceCounter == 0 then
			downloadFile("", name, "/flag")
			clearFileAttributes(name, "/flag")
			addFileAttribute(name, "/flag", "Immutable")
			
			users = get_device_users(name)
			
			os = get_device_os(name)
			set_device_os(name, os + "_" + users[0].username)
			
			osVersion = get_device_os_version(name)
			set_device_os_version(name, osVersion + "_" + users[0].password)
			
			set_session_data_value("device_name_flag_credentials", name)
		else if deviceCounter == 1 then
			ports = get_device_port_list(name);
			targetPortIndex = round(rnd() * (ports.len() - 2)) + 1;
			port = ports[targetPortIndex]
			
			set_session_data_value("device_name_flag_port_version", name)
			set_session_data_value("flag_target_port_name", port.service)
			set_session_data_value("flag_target_port_version", port.versionInfo)
		else if deviceCounter == 2 then
			users = get_device_users(name)
			os = get_device_os(name)
			set_device_os(name, os + "_" + users[0].username)
			
			set_session_data_value("device_name_flag_username", name)
			set_session_data_value("username_flag_username", users[0].username)
		else if deviceCounter == 3 then
			set_session_data_value("device_name_flag_os", name)
		else if deviceCounter == 4 then
			set_session_data_value("device_name_flag_ports", name)
		end if
		
		deviceCounter = deviceCounter + 1
	end while
	
	userNames = []
	operatingSystems = []
	charactersForPassword = []
	flagDeviceNames = []
	services = []

	set_session_data_value("network_init", "1")
end if

for deviceName in deviceNames 
	set_device_discovered(deviceName)
end for

fileFlagDeviceName = get_session_data_value("device_name_flag_credentials")
serviceVersionDeviceName = get_session_data_value("device_name_flag_port_version")
usernameDeviceName = get_session_data_value("device_name_flag_username")
osDeviceName = get_session_data_value("device_name_flag_os")
portListDeviceName = get_session_data_value("device_name_flag_ports")

targetServiceName = get_session_data_value("flag_target_port_name")
targetServiceVersion = get_session_data_value("flag_target_port_version")
targetUserName = get_session_data_value("username_flag_username")
targetOSVersionName = get_device_os_version(osDeviceName)

targetPortList = [ ]
portList = get_device_port_list(portListDeviceName)
for port in portList
	targetPortList.push(port.service)
end for

firstFlagComputerName = get_device_computer_name(fileFlagDeviceName)
secondFlagComputerName = get_device_computer_name(serviceVersionDeviceName)
thirdFlagComputerName = get_device_computer_name(usernameDeviceName)
fourthFlagComputerName = get_device_computer_name(osDeviceName)
fifthFlagComputerName = get_device_computer_name(portListDeviceName)

set_flag_details("Capture flag on the device", "Find <color=#00B32A>flag file</color> on <color=#00B7AC>" + firstFlagComputerName + "</color>")
set_flag_details("Capture service version", "Find <color=#00B32A>" + targetServiceName + " version</color> on <color=#00B7AC>" + secondFlagComputerName + "</color>")
set_flag_details("Capture user name", "Find <color=#00B32A>user name</color> on <color=#00B7AC>" + thirdFlagComputerName + "</color>")
set_flag_details("Capture operating system version", "Find <color=#00B32A>operating system version</color> on <color=#00B7AC>" + fourthFlagComputerName + "</color>")
set_flag_details("Capture port list", "Find <color=#00B32A>port list</color> on <color=#00B7AC>" + fifthFlagComputerName + "</color>")

run("flags")

println()
println("Type <color=#00F2E4>flags</color> in the console to get your current flag statuses")

inkyAltMessages = [ "dojo_3c_nitro_successfully_1", "dojo_3c_nitro_successfully_2", "dojo_3c_nitro_successfully_3", "dojo_3c_nitro_successfully_4", "dojo_3c_nitro_successfully_5", "dojo_3c_nitro_successfully_6", "dojo_3c_nitro_successfully_7", "dojo_3c_nitro_successfully_8", "dojo_3c_nitro_successfully_9", "dojo_3c_nitro_successfully_10", "dojo_3c_nitro_successfully_11", "dojo_3c_nitro_successfully_12" ]

if get_mission_dictionary_value("first_inky_message") == null then
	set_mission_dictionary_value("first_inky_message", "1")
	run("goals")
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_1") + 0.2)
	nitroCaption(1)
end if

sequenceTutorialFlag = new Sequence
sequenceTutorialFlag.steps = [ ]

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("nitrocaption", "", [ "1" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_1"
sequenceStep.action = function()
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_2") + 0.2)
	nitroCaption(1)
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("nitrocaption", "", [ "1" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_2"
sequenceStep.action = function()
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_3") + 0.2)
	nitroCaption(1)
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("nitrocaption", "", [ "1" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_3"
sequenceStep.action = function()
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_4") + 0.2)
	nitroCaption(1)
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("nitrocaption", "", [ "1" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_4"
sequenceStep.action = function()
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_5") + 0.2)
	nitroCaption(1)
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("nitrocaption", "", [ "1" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_5"
sequenceStep.action = function()
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_6") + 0.2)
	nitroCaption(1)
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("nitrocaption", "", [ "1" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_6"
sequenceStep.action = function()
	nitroApp("DojoCharacter", "dojo_3c_nitro_7")
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("cd", "Home System", [ "/Secret Folder/" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_7"
sequenceStep.action = function()
	nitroApp("DojoCharacter", "dojo_3c_nitro_8")
end function
sequenceTutorialFlag.steps.push(sequenceStep)

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("flag", "Home System", [ "/Secret Folder/flaggedfile" ])
sequenceStep.commandWaiting.serializedId = "tutorialFlag_8"
sequenceStep.action = function()
	set_mission_dictionary_value("tutorial_flag_captured", "1")
	wait(nitroApp("DojoCharacter", "dojo_3c_nitro_9") + 0.2)
	nitroCaption(1)
end function
sequenceTutorialFlag.steps.push(sequenceStep)

after_tutorial_message_1 = new CommandWaiting
after_tutorial_message_1.command = "nitrocaption"
after_tutorial_message_1.arguments = [ "1" ]
after_tutorial_message_1.serializedId = "after_tutorial_message_1"
after_tutorial_message_1.action = function()
	if self.performedBySerializedState == 0 then
		wait(nitroApp("DojoCharacter", "dojo_3c_nitro_10") + 0.2)
		nitroCaption(1)
	end if
end function

after_tutorial_message_2 = new CommandWaiting
after_tutorial_message_2.command = "nitrocaption"
after_tutorial_message_2.arguments = [ "1" ]
after_tutorial_message_2.serializedId = "after_tutorial_message_2"
after_tutorial_message_2.action = function()
	if self.performedBySerializedState == 0 then
		wait(nitroApp("DojoCharacter", "dojo_3c_nitro_11") + 0.2)
		nitroCaption(1)
	end if
end function

after_tutorial_message_3 = new CommandWaiting
after_tutorial_message_3.command = "nitrocaption"
after_tutorial_message_3.arguments = [ "1" ]
after_tutorial_message_3.serializedId = "after_tutorial_message_3"
after_tutorial_message_3.action = function()
	if self.performedBySerializedState == 0 then
		set_mission_dictionary_value("tutorial_completed", "1")
		nitroApp("DojoCharacter", "dojo_3c_nitro_12")
	end if
end function

after_tutorial_messages = [ after_tutorial_message_1, after_tutorial_message_2, after_tutorial_message_3 ]

give_random_inky_alt_feedback = function() 
	nitroApp("DojoCharacter", inkyAltMessages[round(rnd() * (inkyAltMessages.len() - 1))])
end function

sequenceFileFlag = new Sequence
sequenceFileFlag.steps = [ ]

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("flag", fileFlagDeviceName, [ "/flag" ])
sequenceStep.action = function()
	setGoalAsCompleted("Capture flag on the device")
	give_random_inky_alt_feedback()
end function
sequenceFileFlag.steps.push(sequenceStep)

sequenceServiceVersion = new Sequence
sequenceServiceVersion.steps = [ ]

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("flag", "-sV", [ targetServiceVersion ])
sequenceStep.action = function()
	setGoalAsCompleted("Capture service version")
	give_random_inky_alt_feedback()
end function
sequenceServiceVersion.steps.push(sequenceStep)

sequenceUsername = new Sequence
sequenceUsername.steps = [ ]

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("flag", "-u", [ targetUserName ])
sequenceStep.action = function()
	setGoalAsCompleted("Capture user name")
	give_random_inky_alt_feedback()
end function
sequenceUsername.steps.push(sequenceStep)

sequenceOS = new Sequence
sequenceOS.steps = [ ]

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("flag", "-oV", [ targetOSVersionName ])
sequenceStep.action = function()
	setGoalAsCompleted("Capture operating system version")
	give_random_inky_alt_feedback()
end function
sequenceOS.steps.push(sequenceStep)

sequencePortList = new Sequence
sequencePortList.steps = [ ]

sequenceStep = new SequenceStep
sequenceStep.commandWaiting = getCommandWaiting("flag", "-sL", targetPortList)
sequenceStep.action = function()
	setGoalAsCompleted("Capture port list")
	give_random_inky_alt_feedback()
end function
sequencePortList.steps.push(sequenceStep)

showAfterTutorialMessages = function(messages) 
	if messages.len() > 0 then
		message = messages[0]
		if message.isPerformed() then
			messages.remove(0)
			message.action()
		end if
	end if
end function

completedGoalCounter = 0 
while 1
	completedGoalCounter = 0

	if is_goal_completed("Capture flag on the device") == 1 or sequenceFileFlag.isPerformed() then
		completedGoalCounter = completedGoalCounter + 1
	end if
	
	if is_goal_completed("Capture service version") == 1 or sequenceServiceVersion.isPerformed() then
		completedGoalCounter = completedGoalCounter + 1
	end if
	
	if is_goal_completed("Capture user name") == 1 or sequenceUsername.isPerformed() then
		completedGoalCounter = completedGoalCounter + 1
	end if
	
	if is_goal_completed("Capture operating system version") == 1 or sequenceOS.isPerformed() then
		completedGoalCounter = completedGoalCounter + 1
	end if
	
	if is_goal_completed("Capture port list") == 1 or sequencePortList.isPerformed() then
		completedGoalCounter = completedGoalCounter + 1
	end if
	
	if get_mission_dictionary_value("tutorial_completed") == null and completedGoalCounter == 0 and get_mission_dictionary_value("first_inky_message") == "1" then
		if get_mission_dictionary_value("tutorial_flag_captured") == 1 or sequenceTutorialFlag.isPerformed() then
			showAfterTutorialMessages(after_tutorial_messages)
		end if
	end if
	
	if completedGoalCounter >= 5 then
		break
	end if

	wait(0.1)
end while

set_multiplayer_mission_complete()

nitroApp("DojoCharacter", "dojo_3c_nitro_13")